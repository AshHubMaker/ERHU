# Erhu Tuner (Flipper Zero)

**Controls**
- LEFT = Inner (D4)
- RIGHT = Outer (A4)
- OK = Toggle play/stop
- BACK (hold) = Quit
- UP/DOWN = Volume +/-

**Build**
- Put this folder into your apps source tree and build with `ufbt`/FBT (same as other apps).
- Resulting `.fap` goes to `apps/Media` on the SD card.

